﻿
Partial Class Default4
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim optionID As String = Session("OptionID")

        Response.Write(optionID)
    End Sub

    Protected Sub Info_btn_Click(sender As Object, e As EventArgs)
        If (Page.IsValid) Then
            Response.Redirect("~/Thank_You.aspx")
        End If
    End Sub

End Class