﻿Public Class Menu
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim myService As New PizzariaWS.WebService1

        rptMenuOptions.DataSource = myService.SelectMenuOptions()
        rptMenuOptions.DataBind()
    End Sub

    Private Sub rptMenuOptions_ItemCommand(source As Object, e As System.Web.UI.WebControls.RepeaterCommandEventArgs) Handles rptMenuOptions.ItemCommand

        Dim command As String = e.CommandName
        Dim optionID As String = e.CommandArgument

        Session("OptionID") = optionID
        Response.Redirect("~/MembersOnly/Order.aspx")

    End Sub


End Class