﻿
Partial Class Default6
    Inherits System.Web.UI.Page

End Class
