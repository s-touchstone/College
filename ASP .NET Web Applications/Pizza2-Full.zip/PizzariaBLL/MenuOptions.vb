﻿Imports System
Imports System.Configuration
Imports System.Data
Imports System.Data.SqlClient
Imports System.Text
Imports System.Web
Imports System.Xml
Imports System.Net
Imports System.ComponentModel
' Imports MySql.Data.MySqlClient

Public Class MenuOptions

    Public Class MenuOptions
        Public Property OptionID As Integer
        Public Property Title As String
        Public Property Description As String
        Public Property Price As Decimal
    End Class

    Public Function SelectMenuOptions() As MenuOptions()

        Dim rc() As MenuOptions = Nothing
        Dim myCommand As SqlClient.SqlCommand = Nothing
        Dim myReader As SqlClient.SqlDataReader = Nothing
        Dim myConnection As SqlClient.SqlConnection = Nothing

        Try

            myConnection = New SqlClient.SqlConnection("Server=cbcc-206-smart;Database=Pizzeria;Uid=sa;")
            myConnection.Open()

            myCommand = New SqlClient.SqlCommand("SELECT * FROM MenuOptions;", myConnection)
            With myCommand
                .CommandType = CommandType.Text
                .Parameters.Clear()
            End With

            myReader = myCommand.ExecuteReader()

            Dim idx As Integer = 0

            While myReader.Read
                ReDim Preserve rc(idx)
                rc(idx) = New MenuOptions
                rc(idx).OptionID = myReader("OptionID")
                rc(idx).Title = myReader("Title")
                rc(idx).Description = myReader("Description")
                rc(idx).Price = myReader("Price")
                idx = idx + 1
            End While

        Catch ex As Exception
            rc = Nothing
        Finally
            If myConnection IsNot Nothing Then
                myConnection.Close()
                myConnection.Dispose()
            End If
        End Try

        Return rc

    End Function
End Class
